# Research, writing and visuals

Research modes keep search/screening protocols and reader cards; evidence keeps
identity/locator/support/counterevidence distinct. Method supports empirical and
literary argument/comparison without inventing results.

Write supports VI, EN, bilingual and translation with minimal edits, task glossary,
protected regions and factual deltas. Taste is an advisory critic, not human gold.
[Venue profiles](../core/profiles/venue/isolation.md) isolate journal/conference,
year/track/article type and ranking system/category/year.

[Native document binding](../extensions/native-documents/contract.json) retains an
unavailable/null bundled default. A trusted task can separately select a permitted
SVG renderer with an explicit project/task/host
[binding record](../core/contracts/visual-engine-binding.schema.json). The record
stays in that project's task output, outside source/dist, and references actual
version/render process receipts and their input SVG/output PNG/log bytes. Bind the
absolute executable path, current SHA-256 and observed version; all observation
references are canonical project-relative paths. Its capability is only
`svg-render`, not native editing or scientific acceptance.

Run the portable [read-only checker](../scripts/check-visual-engine.py):

```text
python -I <relocated-checker-path> --project <absolute-project-root> --task <task-id> --host <claude|codex|cursor|agy> --binding <project-relative-binding.json> --capability svg-render
```

The checker uses its packaged [schema validator](../core/schema.py) and does not
invoke/install the engine or call a provider. Each closed process receipt includes
`command`, `exit_status=0`, `executable_sha256`, exact `version`, hashed project-relative
`stdout`/`stderr` references, `status=completed-unreviewed` and
`cleanup=owned-process-group-closed`. The version command must be the selected
executable with `--version`, with matching version output. The render receipt also
binds `input_sha256`/`render_sha256`; its command names that exact SVG and PNG using
`-o`/`--output`/`--output=`, optionally `--format png` or `--format=png`. Shell wrappers,
extra engine flags, missing evidence, drift and project/task/host mismatches fail
closed. Invalid explicit bindings do not fall back; absent bindings remain
unavailable. Integrity checks cannot authenticate a fabricated receipt or grant
permissions: the controller retains actual host observations and authorization.

An accepted task binding leaves global/default extension status unchanged and
allows the authorized host to create SVG source and call only the observed renderer
route. The final handoff still includes the SVG, final render and hash-bound QA:
source-to-mark mapping, real open/render/editability evidence and unresolved gates.
An earlier engine probe does not qualify the final artifact. Charts require real
data, mechanisms source/inferred edges and artwork an illustrative label.
Scientific meaning, native editability, render/accessibility and exact final hashes
have independent gates.

All six domain skills are experimental. Corpus rights, human VI/EN/domain reviewers
and native visual receipts remain required for stable qualification.

Optional reporting, publisher and language reference snapshots use a standalone
reader and explicit [rights/provenance contract](contracts.md). Reporting lookup
serves matching clinical/health study designs; publisher profiles retain dated and
stale warnings; the English fragment supplies optional language advice.

Five separate actual-source packs supply bounded Wikisource passages, PMC article
excerpts, dated published World Bank observations, pinned Django code fixtures and
the first ten UCI Bank Marketing rows. The World Bank pack supplies observed chart
values with its snapshot date, source hashes and blank-unit caveat. The bounded
VI/PMC samples are not complete genre corpora or human gold. Exact venue policy,
factual fidelity, human taste, scientific acceptance and final visual QA retain
their separate gates.
