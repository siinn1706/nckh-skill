# Engineer kit

Thirteen domains cover scout, debug, fix, test, code-review, security, context, docs,
frontend, backend, data, devops and git. Diagnose/review-only requests preserve product
bytes. Fix needs a proven cause and meaningful regression evidence. Data changes need
a backup before mutation; deployment/Git publication retain explicit target authority.

[nckh-xia](../skills/tooling/nckh-xia/SKILL.md) is separate tooling: compare reports;
port/improve plan. No implementation/install and no shadow of upstream ak-xia.
Framework/provider/upstream adapters are unavailable until selected and qualified.

Local deterministic checks are not production/provider/native acceptance.
No source body/code from paid AgentKit bundles is redistributed.
