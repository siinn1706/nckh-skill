"""Case validation and honest evidence aggregation; no autonomous paid runs."""

import json
from pathlib import Path

from core.build import load_json, verify_source_lock
from core.paths import contained
from core.schema import ContractError, validate_record


BASELINES = {"no-skill", "relevant permitted upstream", "nckh-same-agent", "nckh-selective-delegation"}


def validate_case_manifest(record, identities):
    validate_record("skill-cases", record)
    if record["skill_id"] not in identities or len(record["cases"]) != 4:
        raise ContractError("case manifest requires one approved identity and four cases")
    cases = {}
    for case in record["cases"]:
        if (case["skill_id"] != record["skill_id"] or case["id"] != case["skill_id"] + ":" + case["type"]
                or case["id"] in cases):
            raise ContractError("duplicate or mismatched case identity/type")
        receipt = case["receipt_reference"]
        if receipt is not None and (not isinstance(receipt, str) or not receipt.strip()):
            raise ContractError("case receipt must be a nonempty reference or null")
        if case["status"] != "not-run" and not receipt:
            raise ContractError("case result has no actual receipt")
        if case["type"] == "negative":
            if case["expected_route"] != "reject-this-skill" or "route" not in case["oracle"]:
                raise ContractError("negative oracle must require rejection, ownership handoff and no task execution")
            acceptance = " ".join(case["oracle"]["acceptance"]).casefold()
            if not all(text in acceptance for text in ("reject", "owner", "handoff", "do not execute")):
                raise ContractError("negative acceptance does not cover the declared rejection route")
        elif case["expected_route"] != case["skill_id"] or "route" in case["oracle"]:
            raise ContractError("non-negative case requires its skill route")
        cases[case["id"]] = case
    return cases


def validate_required_families(record, identities, cases):
    validate_record("required-families", record)
    families = record["families"]
    if len(families) != 19 or len({f["id"] for f in families}) != 19:
        raise ContractError("all 19 unique required case families must remain")
    for family in families:
        if len(set(family["skills"])) != len(family["skills"]):
            raise ContractError("duplicate family skill mapping")
        for identity in family["skills"]:
            if identity not in identities or not set(identities[identity]["eval_ids"]) <= cases.keys():
                raise ContractError("required family maps to unknown skill/cases")
        receipt = family["receipt_reference"]
        if receipt is not None and (not isinstance(receipt, str) or not receipt.strip()):
            raise ContractError("family receipt must be a nonempty reference or null")
        if family["status"] != "not-run" and not receipt:
            raise ContractError("family result requires an actual receipt")
    return families


def validate_protocol(protocol):
    validate_record("qualification-protocol", protocol)
    if len(protocol["baselines"]) != 4 or set(protocol["baselines"]) != BASELINES:
        raise ContractError("all four approved baseline variants must remain")
    if set(protocol["split"]["by"]) != {"document", "author", "topic", "claim-family"}:
        raise ContractError("qualification partition axes changed")
    required = {"provider/human run before its freeze and grant", "inventing human labels",
                "tuning on protected holdout", "weakening cases to pass"}
    if not required <= set(protocol["forbidden"]):
        raise ContractError("qualification safety/holdout invariants missing")
    return protocol


def validate_cases(root):
    root = Path(root)
    catalog = validate_record("catalog", load_json(root / "core/registry/catalog/skills.json"))
    identities = {row["id"]: row for row in catalog["skills"]}
    if len(identities) != 37:
        raise ContractError("exactly 37 unique approved identities required")
    cases = {}
    for path in (root / "evals/cases").glob("*/*.json"):
        record = load_json(path)
        if "skill_id" not in record:
            continue
        validated = validate_case_manifest(record, identities)
        if cases.keys() & validated.keys():
            raise ContractError("duplicate case identity across manifests")
        cases.update(validated)
    for skill in identities.values():
        if set(skill["eval_ids"]) != {skill["id"] + ":" + t for t in ["positive", "negative", "outcome", "failure"]}:
            raise ContractError("skill requires positive/negative/outcome/failure IDs")
        if not set(skill["eval_ids"]) <= cases.keys():
            raise ContractError("missing required skill case")
        if skill["status"] == "stable":
            raise ContractError("this candidate has no complete scoped stable qualification")
    families = validate_required_families(load_json(root / "evals/cases/required-families.json"), identities, cases)
    protocol = validate_protocol(load_json(root / "evals/protocols/qualification.json"))
    rubrics = load_json(root / "evals/rubrics/catalog.json")
    if len(rubrics["rubrics"]) != 5 or {row["id"] for row in rubrics["rubrics"]} != {"outcome", "vi-taste", "en-fidelity", "domain", "scientific-visuals"}:
        raise ContractError("all five scoped qualification rubrics are required")
    for rubric in rubrics["rubrics"]:
        if not contained(root / "evals/rubrics", rubric["path"]).is_file() or not rubric["reviewer"]:
            raise ContractError("rubric requires real criteria and a reviewer role")
    if rubrics["reviewer_approval"] != "pending" or rubrics["thresholds"] is not None:
        raise ContractError("this candidate has no observed human rubric approval")
    runtime = load_json(root / "evals/cases/runtime/invocation-matrix.json")["cases"]
    installer = load_json(root / "evals/cases/installer/acceptance.json")
    if {row["os"] for row in installer["os_tracks"]} != {"Windows", "macOS", "Linux"}:
        raise ContractError("all three installer OS tracks must remain visible")
    if not installer["cases"] or len({row["id"] for row in installer["cases"]}) != len(installer["cases"]):
        raise ContractError("installer acceptance requires unique scenarios")
    for case in installer["cases"]:
        if not case.get("scenario") or not case.get("oracle") or case["status"] != "not-run":
            raise ContractError("installer native/OS acceptance has no execution receipt in this candidate")
    if len(runtime) != 224 or len({c["id"] for c in runtime}) != 224:
        raise ContractError("all eight surface/entrypoint/mode/invocation tracks must remain")
    lock = verify_source_lock(root)
    return {"schema_version": 1, "structural_validation": "pass", "evidence_class": "static",
            "identities": len(identities), "skill_cases": len(cases), "required_families": len(families),
            "native_invocation_cells": len(runtime), "source_files_pinned": len(lock["files"]),
            "rubrics": len(rubrics["rubrics"]), "rubric_approval": rubrics["reviewer_approval"],
            "installer_acceptance_cases": len(installer["cases"]), "installer_os_qualification": "unverified",
            "agent_cases_not_run": sum(c["status"] == "not-run" for c in cases.values()),
            "native_cells_not_run": sum(c["status"] == "not-run" for c in runtime),
            "qualification": "pending", "human_freeze": protocol["freeze"],
            "cost": "unknown", "accepted_task_count": 0, "cost_per_accepted_task": "undefined"}


def development_round(protocol, *, changes, exposed_holdout=False):
    validate_protocol(protocol)
    if type(changes) is not int or changes < 1 or type(exposed_holdout) is not bool:
        raise ContractError("development round must be an integer starting at one with explicit exposure")
    if changes > protocol["development_max_rounds"]:
        raise ContractError("new human authorization required after three development rounds")
    if not exposed_holdout:
        raise ContractError("protected holdout pending/NOT_CALLABLE: private route, freeze, rights and human grant required")
    return {"split": "development",
            "blindness": "unverified", "human_gold": "unverified"}
