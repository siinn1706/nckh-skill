"""Structural guards. Semantic entailment and human quality remain reviewer-owned."""

from core.paths import digest_file
from core.schema import ContractError


FACT_DIMENSIONS = {"numbers", "units", "denominators", "negation", "modality",
                   "certainty", "population", "time", "causality", "terminology",
                   "citations", "limitations"}


def factual_delta(before, after, *, protected_before=(), protected_after=()):
    if not FACT_DIMENSIONS <= before.keys() or not FACT_DIMENSIONS <= after.keys():
        raise ContractError("complete declared factual slots are required; extraction is not certified")
    changes = {key: {"before": before[key], "after": after[key]}
               for key in sorted(FACT_DIMENSIONS) if before[key] != after[key]}
    if protected_before != protected_after:
        changes["protected_regions"] = {"before": protected_before, "after": protected_after}
    return {"status": "pending-evidence" if changes else "declared-slots-preserved",
            "changes": changes, "semantic_fidelity": "unverified"}


def check_claim_bundle(claim, evidence, sources, *, exact_quote=False):
    """Validate bindings, never infer semantic support from a DOI or a hash."""
    if claim["verdict"] != "supported" or not claim["evidence_ids"]:
        return "pending"
    for evidence_id in claim["evidence_ids"]:
        item = evidence.get(evidence_id)
        if item is None:
            return "pending"
        source = sources.get(item["source_id"])
        if source is None or item["source_sha256"] != source["sha256"]:
            return "stale"
        if source["status"] != "current" or source["access"] not in {"full-text", "user-supplied"}:
            return "pending"
        if not item.get("locator", {}).get("value") or not item.get("context"):
            return "pending"
        if source.get("edition") != item.get("edition"):
            return "stale"
        if exact_quote and (item.get("ocr") == "unverified" or
                            item.get("ocr") == "visual-checked" and not item.get("visual_check_reference")):
            return "pending"
    return "bindings-valid-support-still-reviewer-owned"


def ranking_known(ranking):
    return bool(ranking and all(ranking.get(key) for key in
                ["system", "category", "metric_year", "as_of", "evidence_reference"])
                and ranking.get("quartile") in {"Q1", "Q2", "Q3", "Q4"})


def active_venue(profiles):
    if len(profiles) != 1:
        raise ContractError("one active venue profile; do not union rules")
    profile = profiles[0]
    if not all(profile.get(key) for key in ["venue_id", "venue_type", "year", "track", "article_type", "revision"]):
        raise ContractError("venue identity/year/track/article type/revision are required")
    return profile


def check_visual_receipt(receipt, files):
    required = {"source", "data", "artifact", "render", "manifest"}
    if not required <= files.keys() or not required <= receipt.get("hashes", {}).keys():
        return "pending"
    if not all(receipt.get(key) for key in ["viewer_version", "font_version", "qa_run_reference"]):
        return "pending"
    if any(digest_file(path) != receipt["hashes"][kind] for kind, path in files.items()):
        return "stale"
    return "hashes-current-native-and-scientific-gates-separate"


def require_operation(operation, *, grant, backup_reference=None):
    if operation not in grant:
        raise ContractError(f"operation outside actual grant: {operation}")
    if operation in {"schema-change", "data-change"} and not backup_reference:
        raise ContractError("backup required before schema/data change")


def xia_mode(flags):
    allowed = {"--compare": "report-only", "--port": "plan-only", "--improve": "plan-only"}
    if len(flags) > 1 or any(flag not in allowed for flag in flags):
        raise ContractError("unsupported or conflicting Xia mode")
    return allowed[flags[0]] if flags else "plan-only"


def metric(numerator, denominator, *, time_range, population):
    if denominator is None or denominator <= 0 or numerator < 0 or numerator > denominator:
        raise ContractError("valid actual numerator/denominator required")
    if not time_range or not population:
        raise ContractError("time range and population required")
    return {"rate": numerator / denominator, "numerator": numerator,
            "denominator": denominator, "time_range": time_range,
            "population": population, "causal_lift": "unverified"}


def experiment_design(design):
    fields = {"hypothesis", "unit", "randomization", "allocation", "primary_metric",
              "denominator", "guardrails", "sample_rationale", "stopping", "analysis"}
    if not fields <= design.keys() or not all(design[key] for key in fields):
        raise ContractError("complete experiment assumptions/protocol required")
    if design["stopping"] == "first-significant-p-value":
        raise ContractError("unplanned peeking cannot establish a stopping rule")
    return "protocol-recorded-statistical-review-pending"
