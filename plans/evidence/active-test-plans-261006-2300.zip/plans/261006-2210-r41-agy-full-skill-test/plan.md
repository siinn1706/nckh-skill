---
title: "NCKH r41 Antigravity native test"
description: "Kế hoạch kiểm thử native đầy đủ 43 skill NCKH r41 trên AGY CLI và IDE bằng cùng bộ input, với evidence độc lập theo surface."
status: pending
priority: P1
effort: 2d
branch: null
tags: [nckh, r41, native, agy, qualification]
blockedBy: []
blocks: []
created: 2026-10-06
---

# NCKH r41 — Antigravity (AGY) native test

## Mục tiêu và phạm vi

Kiểm thử cùng một bộ 43 skill, 172 case tổng hợp và toàn bộ supplemental case trên hai surface `agy-cli` và `agy-ide`. Mỗi case có session mới, record riêng và không suy diễn bằng chứng IDE từ CLI, file package hoặc adapter docs. Kế hoạch chỉ mô tả execution; turn hiện tại chỉ được phép tạo plan, testcase đã ủy quyền và kiểm tra cấu trúc cục bộ.

`resource_access` phải giữ `on`; project hooks là advisory/nonblocking, global hooks `off`. Không sửa skill, source-lock, cài đặt, gọi provider/paid run, chạy native, chạy protected holdout hay phát hành.

## Non-goals

Delivery này chỉ tạo plan/testcase/report và kiểm tra local; sửa skill, thay source pin, triển khai global và chứng nhận stable/scientific nằm ngoài scope.

## Luồng dữ liệu và dependency

- Input: `testcases.json` (215 skill cases = 172 base + 43 fixture, 12 domain và 20 writer scenario), fixtures, baseline và report template trong [shared suite](../261006-2210-r41-shared-testcases/), cùng package r41/adapter/manifest/source-lock.
- Transform: pin hash → preflight → chạy từng input trên CLI/IDE → thu discovery/invocation/resource/model/hook trace → phân loại kết quả.
- Output: `plans/runs/r41-agy-<attempt>/` và report `plans/reports/test-261006-2210-r41-agy-<attempt>.md`; mọi thiếu, block, retry và not-run đều giữ nguyên.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | [Pin, isolate và preflight](./phase-01-pin-isolate-preflight.md) | Pending |
| 2 | [Chạy 43 skill và supplemental](./phase-02-run-43-skills.md) | Pending |
| 3 | [Resources, hooks, native agent và installer](./phase-03-resources-hooks-installer.md) | Pending |
| 4 | [Report, retry và cleanup](./phase-04-report-cleanup.md) | Pending |

## Acceptance criteria

- [x] Hai surface AGY được lập record độc lập; mỗi surface bao phủ 247 case (215 skill = 172 base + 43 fixture, 12 domain, 20 writer), tức 494 case/host; native matrix 56 invocation + 64 writer cells/host được ghi ở chiều coverage riêng.
- [x] Record lưu version host, model requested/resolved/effective, discovery, invocation, output/resource hash, trace, stdout/stderr, exit status và retry relation.
- [x] Phân loại `skill`, `test-fixture`, `environment`, `host`; trạng thái `pass/fail/blocked/not-run/pending/unverified` không bị rút gọn.
- [x] Native matrix chỉ là coverage target; không có claim runtime success nếu thiếu quan sát trực tiếp.
- [x] `ak plan validate` và `ak plan parse` của plan này pass; output được lưu trong thư mục plan.

## Rollback và giới hạn

Chỉ dừng process/staging do attempt sở hữu; giữ raw log và receipt, đối chiếu trust trước/sau, không xóa chỉnh sửa có trước. Nếu host/provider/route không gọi được, dừng route đó và ghi `blocked`/`unverified`, không retry vô hạn và không đổi source lock.

<!-- slug: 261006-2210-r41-agy-full-skill-test -->
