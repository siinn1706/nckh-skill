---
phase: 2
title: "Chạy 43 skill và supplemental"
status: pending
priority: P1
effort: "1d"
dependencies: [1]
---

# Phase 2: Chạy 43 skill và supplemental

## Mục tiêu

Chạy cùng input đã pin trên AGY CLI và AGY IDE theo hai luồng độc lập, đủ 215 skill case (172 base + 43 fixture) và 32 scenario case (12 domain + 20 writer); mọi route native chưa được cấp quyền phải dừng có lý do. Đây là execution specification đang pending, không phải claim native run đã sẵn sàng hoặc đã được chấp nhận.

## Yêu cầu và tệp

- Đầu vào chỉ từ `../261006-2210-r41-shared-testcases/testcases.json`, fixture và `execution-guide.md`; không dịch, sửa hoặc tạo scientific gold tổng hợp.
- Oracle chỉ đọc từ `testcase-catalog.md`, `baseline-review.json`, 43 file case dưới `github-publication/nckh-kit/evals/cases/` và runtime matrix. Mỗi skill giữ positive, negative, outcome, failure.
- Tạo dưới `plans/runs/r41-agy-<attempt>/<surface>/<case-slug>/` theo `prepare-case.py`: hash request, record session/discovery, trace invocation, record model, trace resource, stdout, stderr, exit status, quan hệ retry và kết quả.

## Các bước

1. Mở rộng manifest thành đúng 43 skill ID. Trên mỗi surface, lập cùng thứ tự 172 base ID (4 × 43) và 43 fixture ID; tạo 215 record hành vi độc lập/surface.
2. Thêm toàn bộ 12 domain ID và 20 writer ID từ `testcases.json`, thành 247 record/surface và 494 record/host. Chỉ chạy fixture/check hành vi khi route khai báo được hỗ trợ; giữ native matrix ở chiều riêng, không biến thành evidence im lặng.
3. Mở session native mới cho từng case. Trước khi ghi câu trả lời, thu version host, OS, model requested/resolved/effective, permission/trust, vị trí discovery và bytes skill đã đọc.
4. Gọi CLI bằng route skill AGY đã quan sát và IDE bằng route discovery/menu native đã quan sát. Binary CLI, skill copy, adapter, parse TOML/Markdown hoặc receipt của surface khác không thể đóng một cell IDE.
5. Thu lần đọc resource và output hash, event tool/hook, side effect và hash artifact cuối. Giữ log gốc và PID; không tự động dispatch provider hoặc suy ra effective model.
6. Với case negative/ownership/failure, yêu cầu reject hoặc handoff rõ ràng và không có side effect cấm. Route native không gọi được phải ghi `blocked` hoặc `unverified` kèm lý do và dừng cell đó.

## Luồng dữ liệu

Case và fixture đã pin được gửi vào session mới sau discovery và actual skill read. Thu output/tool/resource/model trace rồi đối chiếu oracle. CLI và IDE dùng cùng input hash, nhưng có outcome và session evidence riêng.

## Ma trận kiểm tra

| Surface | Behavioral records | Scenario records | Native coverage target |
|---|---:|---:|---|
| `agy-cli` | 215 | 12 domain + 20 writer = 32 | 28 invocation + 32 writer cells |
| `agy-ide` | 215 | 12 domain + 20 writer = 32 | 28 invocation + 32 writer cells |

Mỗi surface có 247 record hành vi/scenario và mỗi attempt AGY có 494 record. 224 invocation cell lịch sử và 256 writer cell chỉ là target của matrix; lát cắt AGY là 56 + 64 cell và status vẫn `not-run`/`unverified` cho tới khi có evidence AGY trực tiếp.

## Rủi ro, hoàn tác, tiêu chí đạt

- Rủi ro cao: credential provider, native UI hoặc headless bridge có thể thiếu. Giảm thiểu: không đoán bridge; ghi blocker `host`/`environment` và giữ log gốc.
- Rủi ro vừa: tái dùng session làm rò context. Giảm thiểu: session mới cho từng case và snapshot trust/process trước/sau.
- Hoàn tác chỉ dừng process do attempt tạo và giữ từng case record; không xóa user edit hoặc đổi trust global.
- Đạt khi mỗi record trong 494 record host có receipt độc lập hoặc lý do `blocked/not-run/unverified`, không có claim thành công khi chưa quan sát; tiêu chí này vẫn pending cho tới khi được cấp quyền native riêng.
