---
phase: 1
title: "Pin, isolate và preflight"
status: pending
priority: P1
effort: "4h"
dependencies: []
---

# Phase 1: Pin, isolate và preflight

## Mục tiêu

Đóng băng input, route và giới hạn của attempt AGY trước mọi native execution; preflight hiện tại chỉ đọc và kiểm tra cấu trúc cục bộ.

## Context và evidence nguồn

- [Runtime support](../../github-publication/nckh-kit/docs/runtime-support.md) xác định native là `unverified`, AGY crash/timeout/exit cần evidence trực tiếp và CLI binary/file/adapter docs không đủ.
- [Qualification](../../github-publication/nckh-kit/docs/qualification.md) giữ 43 skill experimental, 172 base case, 256 writer native target và 20 supplemental scenario; không dùng static validation làm native receipt.
- [Installation](../../github-publication/nckh-kit/docs/installation.md) quy định project `--hooks advisory`, global hooks `off`, hook closure inactive và route chưa qualify.
- AGY adapter tại `publication-r41/agy/adapter.json`: project `.agents/skills`; CLI global `.gemini/antigravity-cli/skills`; IDE global `.gemini/config/skills`; agents `.agents/agents`/`.gemini/config/agents`; CLI `1.2.13`, IDE `unknown`.
- AGY manifest tại `publication-r41/agy/manifest.json`: package experimental, 43 skill, 6 agent, `resource_access: on`, hooks packaged-inactive/advisory, native qualification unverified, source-lock hash.
- AGY source pin tại `publication-r41/agy/source-lock.json` là revision 41/local-package-only. Báo cáo cài đặt ghi 43 skill, 13 resource group, project/global locations và chưa test discovery/trust/precedence tại `plans/reports/install-261006-2154-nckh-r41-all-agents.md`.
- Local source validation mismatch đã được phát hiện: phải lưu cả `../261006-2210-r41-shared-testcases/source-validation.json` và `published-source-validation.json`, dùng bản published làm frozen comparator; không sửa hoặc refreeze local source.

## Files và ownership

- Chỉ đọc: các file evidence ở trên, `github-publication/nckh-kit/evals/cases/runtime/invocation-matrix.json`, `github-publication/nckh-kit/evals/cases/runtime/writer-invocation-matrix.json`, 43 file `github-publication/nckh-kit/evals/cases/**/nckh-*.json`.
- Bộ test chung chỉ đọc: `../261006-2210-r41-shared-testcases/{testcases.json,testcase-catalog.md,execution-guide.md,integration-testcases.md,baseline-review.json,suite-validation.json,prepare-suite.py,prepare-case.py,verify-suite.py,fixtures/,source-validation.json,published-source-validation.json}`; các file này do owner bộ test chung quản lý.
- Chỉ tạo dưới `plans/runs/r41-agy-<attempt>/`: `pin.json`, `source-validation.json`, `published-source-validation.json`, `host-version.json`, `trust-before.json`, `ownership.json`, `preflight-summary.json` và log lệnh.

## Các bước

1. Xác định các đường dẫn package canonical hiện tại (`publication-r41/agy/*`) và ghi lại đường dẫn thực tế trong receipt.
2. Băm adapter, manifest, source-lock, bộ test chung, fixture, baseline và report template. Khẳng định manifest có 43 skill, `testcases.json` có 215 skill case + 12 domain + 20 writer scenario, mỗi skill có đúng bốn base case và một fixture case; thiếu/thừa/trùng ID thì dừng.
3. Ghi version AGY CLI/IDE quan sát được; giữ `1.2.13` và `unknown` là khai báo adapter cho tới khi host thật báo khác. Ghi riêng root project/global, root agent, trust và precedence quan sát được.
4. Chỉ chạy validator cấu trúc/qualification cục bộ. Giữ exit status khác 0 cùng stdout/stderr gốc cho mismatch inventory source đã biết; đối chiếu published-source validation và không viết lại source pin.
5. Đặt `AGENTKIT_HOME` ở workspace-local cho mọi lệnh `ak` vì `~/.agentkit/plans` mặc định không ghi được. Không đổi preference global hoặc index plan chung.
6. Đóng băng manifest từng attempt gồm hash đầu vào, revision source, host/surface và grant thực tế. Grant hiện tại là `plan-and-structure-only`; lượt chạy native tương lai cần ghi grant riêng trước dispatch.

## Luồng dữ liệu

Bytes package/source/testcase được đối chiếu hash và inventory, sau đó ghi route/trust/visibility cùng manifest đầu vào cố định. Preflight local không tạo model output hoặc side effect bên ngoài.

## Kiểm tra

- Số lượng dự kiến: 43 skill × 4 = 172 base + 43 fixture = 215 skill case, thêm 12 domain và 20 writer = 247 scenario/surface. `invocation-matrix` AGY target is 28 cells/surface and writer matrix target is 32 cells/surface (56 + 64 per host); Các số này là coverage target; chưa có quan sát native.
- Kiểm tra `resource_access=on`, hooks `packaged-inactive`, global hooks `off` và hash source-lock giữ nguyên trước/sau.
- Pin, route, trust hoặc source validation chưa giải quyết phải ghi `blocked`/`unverified` trong run record; dừng route tương ứng.

## Rủi ro, hoàn tác, tiêu chí đạt

- Rủi ro cao: inventory source local chênh lệch làm mất hiệu lực receipt static. Giữ cả receipt local và published; report nguyên mismatch.
- Rủi ro vừa: chưa quan sát version/discovery AGY IDE. Cần host evidence trực tiếp; adapter chỉ là metadata.
- Hoàn tác chỉ xử lý staging/process do attempt sở hữu sau khi giữ hash/log; bảo toàn trust/file/process có trước.
- Đạt khi manifest cố định và preflight summary tái lập được; mọi blocker có lý do và evidence gốc.

