# Report r41 — {host} / {surface} / {attempt}

## Kết quả

Status: {PASS_WITHIN_SCOPE | FAIL | INCOMPLETE}. Đây là {static / deterministic / native / agent-behavior} evidence; human/scientific acceptance: {pending / observed theo rubric}. Không gọi kit stable từ fixture pass.

| Planned | Dispatched | PASS | FAIL | BLOCKED | NOT_RUN | TIMEOUT_UNKNOWN |
|---:|---:|---:|---:|---:|---:|---:|
| | | | | | | |

Dispatched = PASS + FAIL + TIMEOUT_UNKNOWN, nếu BLOCKED xảy ra trước dispatch. Nếu block sau dispatch, ghi flag dispatched riêng và giải thích. Tổng verdict phải bằng planned. Behavioral, native cell, resource-reader, native-resource-consumer và integration counts tách riêng; receipt tái dùng có mapping, không cộng hai lần.

## Subject và môi trường

- r41 package path, manifest/file/closure/source-lock hashes:
- Test suite/input/fixture hashes:
- Host/version/surface/OS/timezone/session/invocation:
- Requested/resolved/effective model và observation source:
- Start/end/elapsed; tokens/cost: null nếu chưa đo:
- Definition path thật host đọc; discovery và precedence evidence:
- Grant/sandbox/trust/config trước và sau:

## Mọi failure và blocker

### {case-id} — {severity} — {skill | fixture/test | environment | host/interface | package/source}

- Steps/input/setup và quyền thực thi:
- Expected oracle:
- Actual observation, error nguyên văn, exit status hoặc terminal state:
- Reproduction nhỏ nhất; evidence links tới transcript/stdout/stderr/artifact/hash:
- Cause: verified hoặc hypothesis, không bịa root cause:
- Impact và proposed fix; skill code chưa sửa:
- Retry attempt và retry_of; original failure giữ nguyên:

## Coverage và pending gates

43-skill matrix, thiếu ID/case cụ thể; 35 resource bindings; native matrix/roles/plugin/hooks/installer đã chạy hoặc blocked. Chỉ báo coverage percent cho metric thật được đo. VI/EN taste, scientific validity, actual corpus, protected holdout, provider economics và unsupported OS giữ trạng thái riêng.

## Cleanup

Owned PID/command/port/workspace đã terminal hoặc còn unknown; config/trust restored hoặc pending; unrelated edits preserved theo hash; residue và rollback issues.

## Unresolved questions

Chỉ liệt kê vấn đề chưa giải quyết cần input thực tế; nếu không có thì bỏ mục.
