"""Check authored suite, frozen input pins and real package closures; no native run."""
import json
import importlib.util
import sys
from pathlib import Path


def main():
    spec = importlib.util.spec_from_file_location('r41_author', Path(__file__).with_name('prepare-suite.py'))
    author = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(author)
    here, root = author.HERE, author.ROOT
    suite = author.read(here / 'testcases.json')
    assert suite['revision'] == '41'
    assert len(suite['skills']) == len(set(suite['skills'])) == 43
    assert len(suite['cases']) == 215
    assert len({c['id'] for c in suite['cases']}) == 215
    for sid in suite['skills']:
        rows = [c for c in suite['cases'] if c['skill_id'] == sid]
        assert {c['type'] for c in rows} == {'positive','negative','outcome','failure','contract'}
    for rel, expected in suite['source_pins'].items():
        assert author.sha(author.SOURCE / rel) == expected, rel
    assert author.sha(author.SOURCE / 'core/registry/source-lock/source-lock.json') == suite['source_lock_file_sha256']
    for rel, expected in suite['fixture_hashes'].items():
        assert author.sha(here / rel) == expected, rel
    assert len(suite['research_domain_scenarios']) == 12
    assert len(suite['writer_scenarios']) == 20
    assert len(suite['scenario_cases']) == 32
    assert len({c['id'] for c in suite['cases'] + suite['scenario_cases']}) == 247
    assert len(suite['installer_acceptance']['cases']) == 10
    sys.path.insert(0, str(author.SOURCE))
    from core.build import verify_bundle
    summaries = {}
    for host, meta in suite['hosts'].items():
        package = Path(meta['package'])
        assert author.sha(package / 'manifest.json') == meta['manifest_sha256']
        assert author.sha(package / 'source-lock.json') == meta['source_lock_sha256']
        manifest = verify_bundle(package)
        assert manifest['source_lock_hash'] == meta['source_lock_hash']
        assert manifest['closure_hash'] == meta['closure_hash']
        assert manifest['resource_access'] == 'on'
        assert {s['id'] for s in manifest['skills']} == set(suite['skills'])
        assert len(meta['resource_cases']) == 35
        assert len(meta['invocation_cells']) == 56
        assert len(meta['writer_native_cells']) == 64
        assert all(c['status'] == 'not-run' for c in meta['resource_cases'])
        summaries[host] = {'package': 'pass', 'skills': 43, 'resource_bindings': 35, 'native_execution': 'not-run'}
    assert all(c['status'] == 'not-run' and c.get('receipt_reference') is None for c in suite['cases'])
    result = {'status':'pass','evidence_class':'static-test-design-integrity','cases':215,'skills':43,'hosts':summaries}
    author.save('suite-validation.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        result = {'status':'fail','evidence_class':'static-test-design-integrity','error':str(error)}
        Path(__file__).with_name('suite-validation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(result,indent=2),file=sys.stderr)
        sys.exit(1)
