# Testcase integration r41

Các case dưới đây chạy trên bản sao disposable của package/project, giữ nguyên subject r41. Mỗi host/surface có result riêng. `PASS` của local codec hay installer không phải native hook prevention. Khi chưa được quyền native/provider/activation thì ghi BLOCKED và report.

## Package, discovery và modes

| ID | Setup / steps | Expected result và evidence |
|---|---|---|
| PKG-01 | Verify manifest, source-lock, catalog và mọi member SHA-256 bằng frozen `core.build.verify_bundle`. | Revision 41; đúng 43 skill, 6 agent, 13 resource group/35 bindings, resource_access on; mismatch phải fail trước native run. |
| PKG-02 | Khởi động fresh IDE/CLI, inventory global/project có cùng IDs; quan sát definition thật đọc. | 43 identity discoverable hoặc danh sách missing/ambiguous rõ; physical path/hash khớp r41; không claim precedence chỉ từ copied files. |
| PKG-03 | Di chuyển package copy sang thư mục khác và reader chạy từ external cwd, Python `-I`, bỏ PYTHONPATH. | Không phụ thuộc checkout/home/PYTHONPATH; hash/rights/provenance giữ nguyên. |
| NATIVE-01 | Chạy từng cell invocation trong testcases.json của host, ghi menu/slash/plain/implicit theo cell. | Actual discovery/invocation/read/route/mode, no authority escalation; unsupported interface BLOCKED. |
| NATIVE-02 | Chạy từng writer native cell VI/EN và alias nckh-write. | Đúng writer owner/locale/action; factual/protected fields giữ; không đoán effective model. |
| NATIVE-03 | Thử read-only, --auto và --interactive trên accepted-plan fixture. | Read-only không product writes; auto hoàn thành reversible local phases; interactive cần feedback đúng artifact hash, stale/missing feedback dừng tại gate. |
| NATIVE-04 | Sáu role riêng: explorer/planner/researcher/maker/reviewer/taste-critic; nếu runtime không hỗ trợ agent thì BLOCKED. | Read-only roles không sửa product; maker chỉ assigned files; requested/resolved/effective model tách; permissions không tăng; capture child output và provenance. |
| PLUGIN-01 | Chỉ trong sandbox được phép: inspect plugin manifest rồi thử discovery/selection riêng nếu host có interface đã xác nhận. | projected/copied/registered/enabled/trusted/tested/session_only riêng; thiếu native observation giữ unverified; không đăng ký global tự động. |

## Resource — 35 bindings mỗi host

Với **mỗi** `hosts.<host>.resource_cases` trong JSON, chạy các bước:

1. Reader được khai báo trong binding; dùng context/query từ frozen `scripts/resource-smoke.py`, không tự đoán domain/genre. Lưu reader argv, raw output, exit code, resource locator/rights/hash.
2. Kiểm `expected_artifact` và `requires` hiện hữu; input snapshot không được chuyển thành hiện hành, human gold hoặc empirical result.
3. Trong native consuming skill, yêu cầu bounded lookup tương ứng; capture actual read và output dùng resource với provenance/limits. Đây là verdict khác reader read.
4. Negative checks trên sandbox copy: resource ID không tồn tại; consumer không được phép; context domain/genre không phù hợp; resource file sửa byte. Reader phải reject/bounded empty/hash error theo contract, không fall back sang record invented. Không sửa package gốc.
5. So sánh blank unit, locators/parent-child, article rights, UCI 17 columns, paired/independent recipe và snapshot dates bằng record thật; không tự fill missing units/labels.

Frozen entrypoint đã kiểm help:

```powershell
python -X utf8 -B github-publication/nckh-kit/scripts/resource-smoke.py --bundle publication-r41/agy --cwd <external-disposable-cwd> --unset-pythonpath --output <run-root>/resource-read.json
```

`external-disposable-cwd` phải nằm ngoài repository và được phép tạo; script chỉ đọc verified bundle. Cursor thay bundle path. Không dùng command này để giả native consumption.

## Hooks — enumerate event theo template đã pin

Lấy mọi event trong `hosts.<host>.hook_template` và codec của package; tạo các subcase bên dưới **cho mỗi event hỗ trợ**, ghi exact host version/surface. Callback không được host phát thì unsupported/unverified. Trước apply config, preview exact target và giữ baseline; project mặc định advisory không chặn. Global hooks luôn off. Nếu muốn thử enforcement riêng cần quyền và config được review; không suy diễn từ advisory warning.

| ID | Fault/setup | Expected observation |
|---|---|---|
| HOOK-01 | Authorized local read/write. | Event decode đúng, allow đúng; native tool result thật và cleanup. |
| HOOK-02 | Protected target hoặc path traversal trong disposable fixture. | Policy phát deny/warning đúng; advisory không chặn operation; native prevention chỉ claim trong qualified enforcement mode. |
| HOOK-03 | Malformed input/unknown field vượt contract. | Bounded parse error/advisory behavior; stderr và exit code thật; không crash không kiểm soát/false PASS. |
| HOOK-04 | Callback output malformed. | Native host reaction được quan sát; host fail-open/fail-closed unknown giữ unverified. |
| HOOK-05 | Callback timeout có process handle. | Native timeout reaction và đúng terminal evidence; không success từ timeout. |
| HOOK-06 | Callback crash/exit nonzero trong disposable handler. | Native exit reaction ghi riêng; AGY failure semantics không được giả định. |
| HOOK-07 | Unsupported tool/event/codec. | Unsupported scope được báo; không claim universal shell/file protection. |
| HOOK-08 | Duplicate registration/invocation. | Không duplicate owned hook record hoặc side effect; preserve unowned config. |
| HOOK-09 | Preview/apply/remove config và sửa một owned entry sau apply. | Preview no-write; apply ownership receipt; remove giữ edited/unowned entries, báo conflict. |

## Installer và retained local suites

Chạy 10 installer acceptance cases nguyên bản tại frozen `evals/cases/installer/acceptance.json`, tách Windows local khỏi macOS/Linux chưa chạy. CLI `--help` là nguồn syntax, không tự tạo flags.

| ID | Steps | Expected result |
|---|---|---|
| INSTALL-01 | install --dry-run trong project/home/state disposable; full kits + agents, copy mode. | Không mutation; exact target diff; project advisory và global --hooks off. |
| INSTALL-02 | Authorized install, doctor, update unchanged r41, uninstall trên sandbox. | Nonzero inventory, ownership/hashes current; idempotent update; uninstall chỉ unchanged owned, cleanup receipt. |
| INSTALL-03 | User edit/unowned collision, rollback interruption và shared ownership từ acceptance fixture. | Không mất edit; conflict/backup/rollback có receipt; không --yes bypass. |
| INSTALL-04 | Windows locked directory và device boundary theo tests. | Fail trước unsafe mutation hoặc rollback rõ; không kill holder/change ACL; retain failed attempt. |
| CLEANUP-01 | So sánh before/after process/trust/config/files, reconcile timeout handles. | Không orphan do attempt start; không xoá user-owned; unresolved terminal/rollback ghi report. |

Các suite có sẵn là coverage local riêng, không thay behavioral scenarios. Khi phase execution được authorize, dùng frozen source:

```powershell
python -X utf8 -B github-publication/nckh-kit/evals/run-evals.py --validate-only --output <run-root>/structure.json
python -X utf8 -B github-publication/nckh-kit/evals/run-evals.py --run-deterministic --output <run-root>/deterministic.json
```

Không sửa tests/skill để vượt failure. Coverage lines/branches chỉ ghi nếu runner thực sự đo; không lấy catalog counts làm code coverage. Mọi unsupported/blocked case vẫn ở denominator planned và được liệt kê.
