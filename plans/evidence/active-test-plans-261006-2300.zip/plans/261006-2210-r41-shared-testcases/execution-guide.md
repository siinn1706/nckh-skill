# Chạy testcase r41 trên AGY và Cursor

## Outcome và giới hạn

Hai plan kiểm tra cùng 43 skill r41 trên AGY và Cursor, cả IDE lẫn CLI, bằng cùng input và oracle. Delivery hiện tại tạo plan, testcase, fixture và report kiểm tra local. Việc chạy native nằm trong các phase pending. Không sửa skill, freeze revision mới, cài lại global hay tự gọi paid provider. Mỗi kết quả native phải có phiên host thực, không suy ra từ file đã cài.

Nguồn evaluation đóng băng: `C:/Users/USER/Downloads/test-skill/github-publication/nckh-kit`. Package subject: `C:/Users/USER/Downloads/test-skill/publication-r41/agy` và `publication-r41/cursor`. Hash chính xác nằm trong [testcases.json](testcases.json). Cây source `nckh-kit` có thêm file chưa pin; xem [baseline review](baseline-review.json). Không dùng receipt lịch sử thay receipt candidate đang chạy.

## Preflight

1. Chạy `python -X utf8 -B plans/261006-2210-r41-shared-testcases/verify-suite.py` từ workspace. Nonzero phải ghi report trước khi chạy tiếp.
2. Ghi version host hiện tại, Windows version, thời gian Asia/Saigon, requested/resolved/effective model riêng; không quan sát được để `unknown`.
3. Tạo run root `plans/runs/r41-<host>-<attempt>/`. Dùng project/home/state riêng khi có cài đặt fixture; chụp baseline trust/config/owned-process trước thao tác. Không thay home thật.
4. Phát hiện skill bằng catalog/menu của host. So sánh 43 IDs với suite và ghi exact physical path/hash. Có nhiều root/global/project phải xác định definition host đọc thật. Không rõ precedence thì `BLOCKED`, không mặc nhiên chọn bản mới.
5. Mỗi testcase mở phiên mới, không mang đáp án/oracle từ case trước vào context. Skill được kiểm tra đọc definition r41 thật. Test thực thi có thể cần quyền host/tool và model budget riêng; nếu chưa có thì giữ `BLOCKED`, không tự bypass.

## Chuẩn bị một case

```powershell
python -X utf8 -B plans/261006-2210-r41-shared-testcases/prepare-case.py --host agy --surface agy-ide --case-id nckh-test:fixture-contract --attempt attempt-01
python -X utf8 -B plans/261006-2210-r41-shared-testcases/prepare-case.py --host cursor --surface cursor-cli --case-id nckh-test:fixture-contract --attempt attempt-01
```

Tool chỉ tạo workspace, input prompt và result template dưới `plans/runs/`; không cài hay chạy host. Mở case workspace trong host, chọn skill bằng cách thực tế host hỗ trợ rồi dán `prompt.md`. Với Cursor IDE thử `/nckh-...` nếu menu đã xác nhận; AGY IDE dùng discovery/selection đang quan sát. CLI không được tự đoán headless flags hoặc giả UI slash bằng plain prompt. Không hỗ trợ một invocation thì ghi `BLOCKED/unsupported-interface`, giữ các invocation khác riêng.

Hai mode phải phân biệt: explicit invocation kiểm tra skill đã chọn; implicit routing chỉ gửi task không chỉ định skill và quan sát selection. Negative cases explicit chọn skill bị đề cử sai và phải reject + handoff, **không thực hiện task của owner khác**. Không đưa oracle vào prompt gửi agent; operator/reviewer dùng oracle sau capture.

## Setup theo loại case

| Loại | Setup và quyền trong disposable workspace | Oracle |
|---|---|---|
| positive | Bind supplied plan/draft/source/data/app vào fixture tương ứng. Quyền sửa local chỉ khi prompt yêu cầu; negative/read-only luôn không sửa product. | Toàn bộ acceptance và forbidden_actions của case gốc. |
| outcome | Tạo workspace mới từ fixture nguyên trạng. Positive/outcome có thể trùng prompt; giữ ID và receipt riêng, ghi redundancy. | Kiểm usable artifact và fidelity; không coi trùng prompt là feature độc lập. |
| negative | Nominated skill rõ ràng; task nằm ngoài owner. | Reject nominated owner, bounded handoff, không thực thi task kia. |
| failure | Gắn failure condition đúng prompt: missing result/reviewer/permission là absent; stale receipt phải có hash cũ khác artifact; malicious log là data. Không fabricate observed host error. | Dừng/tiếp tục bounded đúng contract; không fabricated evidence, không che failure. |
| fixture-contract | Copy fixture gốc bằng prepare-case; dùng prompt bổ sung trong JSON. | Oracle cụ thể theo skill trong catalog. |

Trước dispatch, nếu case cần input không có trong fixture, operator ghi thiếu input và `BLOCKED/fixture`, không để agent đoán rồi tính PASS. Ví dụ `nckh-git:positive/outcome` cần local Git disposable: `git init`, stage `owner-note.txt`, sửa `app.py` chưa stage; chụp status/diff trước/sau. Chỉ thực hiện setup này khi chạy case, không sửa repository chính. Case docs cần actual installer help: dùng frozen installer `--help`, không cài. Case UI ghi screenshot/render pending nếu không chạy browser. Writer cases bind VI/EN passages riêng, giữ quote/citation/negation/modal; `--vi --en` conflict phải no-write. Domain scenarios dùng scenario + requested_owner trong JSON, oracle cho reviewer.

Case original vẫn giữ prompt/input_language; prompt tiếng Việt với metadata EN không được đổi âm thầm. Ghi actual input/output locale riêng. Supplement authored khác base; không regrade lịch sử hoặc thay protected holdout.

## Capture và chấm

Mỗi case giữ `result.json`, full transcript, tool log, stdout/stderr/exit status nếu có, artifact trước/sau và SHA-256. Ghi start/end, host/surface/version/session ID, exact input hash, suite hash, package closure, observed skill reads, invocation kind, permission/egress, requested/resolved/effective model, elapsed time, known token/cost hoặc null. Không lưu credentials/contact/private environment trong report.

`PASS` cần tất cả oracle đúng và trace đủ; `FAIL` khi có observed mismatch; `BLOCKED` khi thiếu interface/input/permission; `NOT_RUN` khi chưa dispatch; `TIMEOUT_UNKNOWN` khi chưa có terminal evidence. Không coi missing log hoặc timeout là PASS. Unknown model riêng không tự biến task thành fail, nhưng model qualification vẫn pending.

Reviewer đọc artifact/log gốc độc lập với câu agent tự chấm. Artifact quality subjective VI/EN và scientific/domain validity giữ pending nếu chưa có reviewer/rubric được chấp nhận. Fixture contract pass chỉ chứng minh behavior trong input synthetic. Không lấy 215 case pass để gọi toàn bộ kit stable.

## Chạy đủ phạm vi

- Mỗi surface: 172 base + 43 fixture + 12 domain + 20 writer = **247 behavioral scenarios**. Mỗi host có hai surface = 494 scenario attempts trước retry, tính riêng observed/blocked/not-run.
- Chạy native matrix của đúng host: 56 invocation cells và 64 writer native cells; đây là chiều discovery/mode/invocation, có thể dùng lại receipt behavior nếu exact input/context/host/version khớp và ghi mapping, không cộng double vào behavior pass count.
- Chạy 35 consumer/resource bindings và integration checks trong [integration testcases](integration-testcases.md). Reader pass và host consumer behavior là hai verdict riêng.
- Chạy tuần tự, ưu tiên mỗi skill một fixture case trước, sau đó base/failure và matrices; không spawn 43 phiên/model một lúc.

## Failure và cleanup

Ghi mọi failure vào report theo [template](report-template.md), phân loại `skill`, `fixture/test`, `environment`, `host/interface`, `package/source`. Lưu nguyên error và reproduction trước đề xuất sửa. User hiện chỉ yêu cầu plan/testcase/report; skill code giữ nguyên. Retry dùng attempt mới với `retry_of`, không ghi đè failure cũ.

Timeout: theo dõi đúng session/PID/generation tới terminal; chưa terminal giữ unknown. Stop chỉ process đã start/owned; không kill broad theo tên. Khôi phục config/trust từ snapshot nếu chính attempt thay đổi; không xoá user edits hay owner khác. Cleanup và diff cuối là gate riêng; failure cleanup phải hiện trong report.

Không có live provider, native observation hoặc human acceptance trong delivery này. Các gate đó để pending trong hai plan.
