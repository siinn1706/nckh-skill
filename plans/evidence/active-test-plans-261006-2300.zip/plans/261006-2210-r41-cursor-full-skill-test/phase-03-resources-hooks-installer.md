---
phase: 3
title: "Resources, hooks, native agent và installer"
status: pending
priority: P1
effort: "4h"
dependencies: [1, 2]
---

# Phase 3: Resources, hooks, native agent và installer

## Mục tiêu

Kiểm tra đường đi resource, hook và installer theo package r41 trên Cursor, tách rõ project/CLI/IDE/global/compatibility roots và không biến cấu hình tĩnh thành bằng chứng host enforcement.

## Yêu cầu và các bước

1. Với `resource_access: on`, đối chiếu toàn bộ 35 resource binding/consumer/reader trong manifest với registry và fixture chung. Ghi resource ID, reader, hash đầu vào, hash đầu ra, provenance/rights và lỗi đọc; không fetch nguồn ngoài hoặc bịa measurement.
2. Theo [integration-testcases](../261006-2210-r41-shared-testcases/integration-testcases.md), lập record PKG-01..PKG-03 và toàn bộ resource negative checks: reader thật, external cwd, Python `-I`, bỏ `PYTHONPATH`, locator/rights/hash, consumer context và byte tamper. Không xem local codec pass là native prevention.
3. Với từng event trong hook template, lập fault matrix HOOK-01..HOOK-09: allow, protected path, malformed input, malformed output, timeout, crash/nonzero, unsupported, duplicate và preview/apply/remove sau edited entry. Project advisory không chặn, global Cursor `off`; event host không phát được ghi `unsupported/unverified`.
4. Kiểm tra native agent NATIVE-04 cho đủ sáu role `explorer/planner/researcher/maker/reviewer/taste-critic`: role read-only không sửa product, maker chỉ sửa file được giao, child output/provenance và ba model field phải tách. Không có runtime hỗ trợ agent thì `blocked`.
5. Kiểm tra PLUGIN-01 theo toàn bộ lifecycle `projected/copied/registered/enabled/trusted/tested/session_only`; chỉ thử discovery/selection trong sandbox được phép, không đăng ký global tự động và thiếu native observation vẫn `unverified`.
6. Đối chiếu 10 installer acceptance case nguyên bản từ `github-publication/nckh-kit/evals/cases/installer/acceptance.json`, cùng INSTALL-01..INSTALL-04/CLEANUP-01 của integration suite. Chỉ khi có authority riêng mới chạy dry-run/doctor/preview trong disposable project; turn hiện tại dừng ở static/local structure checks, không install/update/configure/apply.

## Luồng dữ liệu

Manifest/registry/resource fixture → bounded reader → resource trace/hash → hook/config/agent visibility snapshot → installer preview/doctor receipt (nếu được cấp quyền). Mọi route unsupported hoặc native failure giữ status riêng.

## Tệp và đầu ra

- Chỉ đọc: `publication-r41/cursor/manifest.json`, package `hooks/`, `native/`, `plugin/`, `github-publication/nckh-kit/core/registry/catalog/resources.json`, `github-publication/nckh-kit/scripts/resource-smoke.py`, `github-publication/nckh-kit/evals/cases/installer/acceptance.json`, integration-testcases và hook/installer docs.
- Chỉ tạo dưới run root: `resources/*.json`, `hooks/*.json`, `agents/*.json`, `plugin/*.json`, `installer/*.json`, stdout/stderr và hash. Không sửa package, installed root hoặc config global.

## Rủi ro, hoàn tác, tiêu chí đạt

- Rủi ro cao: advisory config có thể bị hiểu nhầm là prevention. Giảm thiểu: tách policy/config khỏi native event evidence; không claim enforcement.
- Rủi ro cao: root compatibility Cursor lồng nhau có thể đổi discovery/precedence. Giảm thiểu: snapshot mọi root nhìn thấy và ownership trước/sau từng route disposable.
- Hoàn tác chỉ dùng transaction installer đã review khi được cấp quyền riêng; nếu không, chỉ xóa staging của attempt và giữ root/config có trước.
- Đạt khi trace resource-on, hook state, agent visibility, plugin lifecycle và installer status có hash, gắn đúng surface và ghi rõ gate chưa xác minh.
