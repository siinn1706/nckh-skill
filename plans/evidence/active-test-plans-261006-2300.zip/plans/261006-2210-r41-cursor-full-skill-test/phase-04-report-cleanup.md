---
phase: 4
title: "Report, retry và cleanup"
status: pending
priority: P1
effort: "4h"
dependencies: [1, 2, 3]
---

# Phase 4: Report, retry và cleanup

## Mục tiêu

Đóng attempt bằng report tiếng Việt có raw evidence và giới hạn rõ ràng, rồi cleanup chỉ những process/staging do attempt sở hữu.

## Hợp đồng report

1. Kết xuất [report-template](../261006-2210-r41-shared-testcases/report-template.md) thành `plans/reports/test-261006-2210-r41-cursor-<attempt>.md`; giữ run root `plans/runs/r41-cursor-<attempt>/`.
2. Report phải có plan/attempt/timezone Asia/Saigon, host+OS+version, model requested/resolved/effective, hash package/adapter/manifest/source-lock/testcase/baseline/source-validation, surface, discovery, invocation, hash/trace output resource, hook/installer state, link raw log, exit status và quan hệ retry.
3. Bảng tổng hợp phải liệt kê 215 behavioral case + 12 domain + 20 writer case cho từng surface (247/surface, 494/host), coverage target riêng, pass/fail/blocked/not-run/pending/unverified và failure category `skill|test-fixture|environment|host`. Không gộp retry vào pass và không bỏ log lỗi gốc.
4. Nêu riêng source inventory mismatch local so với published validation; không refreeze source-lock. Native result chỉ được gọi observed khi có host/session trace trực tiếp; adapter, package hash, CLI file hoặc matrix không đủ.

## Cleanup và hoàn tác

- Trước cleanup, snapshot process/trust/target hashes. Dừng graceful process do attempt khởi tạo; hard kill chỉ khi process đó không thoát và vẫn xác định đúng PID.
- Giữ raw stdout/stderr, receipts, hashes và failed attempts. Xóa/move chỉ staging/temp do attempt sở hữu sau khi manifest ghi nhận; không đụng process, trust, global hooks, user edits hay unowned files.
- Retry tạo attempt mới, liên kết `retry_of`, giữ nguyên hash đầu vào/source và lý do retry. Timeout/crash/unknown không được đổi thành pass.

## Kiểm tra plan và tiêu chí đạt

- Từ workspace root, với workspace-local `AGENTKIT_HOME`, chạy `ak plan validate plans/261006-2210-r41-cursor-full-skill-test --json --no-interactive` và `ak plan parse plans/261006-2210-r41-cursor-full-skill-test --json --no-interactive`; lưu nguyên output vào `ak-validate.json` và `ak-parse.json` trong thư mục plan.
- Re-read plan và bốn phase; kiểm tra link shared suite, run/report templates, phase dependencies và status `pending`.
- Phase đạt khi report tái lập được từ receipts và nêu mọi unresolved/blocked/not-run; toàn plan vẫn `pending` cho tới khi native authority và runtime evidence hợp lệ. Không claim qualification, stable release, scientific gold hay runtime success.
